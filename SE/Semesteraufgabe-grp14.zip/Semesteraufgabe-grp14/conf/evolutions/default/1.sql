# Users schema
 
# --- !Ups
 
CREATE TABLE User (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    password varchar(255) NOT NULL,
    postalCode int(5) NOT NULL,
    isAdmin bool DEFAULT 0,
    distance int,
    PRIMARY KEY (id)
);
CREATE TABLE ProductCategory (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    isDeactivated bool DEFAULT 0,
    PRIMARY KEY (id)
);
CREATE TABLE Products (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    price Double,
    category_id bigint(20),
    unit varchar(255),
    isAvailable bool DEFAULT 1,
    isDeactivated bool DEFAULT 0,
    PRIMARY KEY (id),
    FOREIGN KEY(category_id) REFERENCES ProductCategory(id)
);
CREATE TABLE Additionals(
    id bigint(20) NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    price Double,
    category_id bigint(20),
    isAvailable bool DEFAULT 1,
    PRIMARY KEY (id),
    FOREIGN KEY(category_id) REFERENCES ProductCategory(id)
);
CREATE TABLE Orders (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    user_id bigint(20) NOT NULL,
    total Double,
    order_date varchar(16),
    duration int,
    status varchar(16),
    PRIMARY KEY (id),
    FOREIGN KEY(user_id) REFERENCES User(id)
);
CREATE TABLE Order_Positions (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    order_id bigint(20) NOT NULL,
    position_id bigint(20) NOT NULL,
    product_id bigint(20) NOT NULL,
    price Double,
    unit Double,
    PRIMARY KEY (id),
FOREIGN KEY(order_id) REFERENCES Orders(id),
FOREIGN KEY(product_id) REFERENCES Products(id)
);
CREATE TABLE Product_Additionals (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    order_position_id bigint(20) NOT NULL,
    additionals_id bigint(20) NOT NULL,
    PRIMARY KEY (id),
FOREIGN KEY(order_position_id) REFERENCES Order_Positions(id),
FOREIGN KEY(additionals_id) REFERENCES Additionals(id)
);

insert into User (name, password, postalCode, isAdmin, distance) Values ('Mario', 'eab2dbbfc93ca4c92599016562365abc', 12345, true, 0);

insert into User (name, password, postalCode, isAdmin, distance) Values ('Padrone', '476b1052e71942fcfd307342c7f4f516', 12345, true, 0);
insert into User (name, password, postalCode, isAdmin, distance) Values ('Emil', 'a615b19358fba76194f28754194f2794', 12345, false, 15);

insert into ProductCategory (name, isDeactivated) Values ('keine Kategorie', false);
insert into ProductCategory (name, isDeactivated) Values ('Pizza', false);
insert into ProductCategory (name, isDeactivated) Values ('Getraenke', false);

insert into Products (name, price, category_id, unit, isAvailable) Values ('Salami', 0.2, 2, 'cm', true);
insert into Products (name, price, category_id, unit, isAvailable) Values ('Schinken', 0.3, 2, 'cm', true);
insert into Products (name, price, category_id, unit, isAvailable) Values ('Diavola', 0.4, 2, 'cm', true);
insert into Products (name, price, category_id, unit, isAvailable) Values ('Spezi', 3.3, 3, 'L', true);
insert into Products (name, price, category_id, unit, isAvailable) Values ('Rotwein', 7.5, 3, 'L', true);

insert into Additionals (name, price, category_id, isAvailable) Values ('Extra Scharf', 0.5, 2, true);
insert into Additionals (name, price, category_id, isAvailable) Values ('Extra Kaese', 0.5, 2, true);
insert into Additionals (name, price, category_id, isAvailable) Values ('Oliven', 0.5, 2, true);
# --- !Downs
 
DROP TABLE User;
DROP TABLE ProductCategory;
DROP TABLE Additionals;
DROP TABLE Products;
DROP TABLE Orders;
DROP TABLE Order_Positions;
DROP TABLE Product_Additionals;