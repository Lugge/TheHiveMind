package services

import dbaccess.CategoryDao
import models.Category

/**
 * Service class for category related operations.
 * 
 * @author safranek, krose
 */
object CategoryService {
  
  /**
   * Adds a new category to the system.
   * @param name name of the new category.
   * @return the new category.
   */
  def addCategory(name: String): Category = {
    // create Product
    val newCategory = Category(-1, name, false)
    // persist and return Product
    return CategoryDao.addCategory(newCategory)   
  }
  
    /**
   * Deletes a category.
   * @param id the id of the category.
   */
  def deleteCategory(id: Long) = {
    // persist and return Product
    CategoryDao.deleteCategory(id)   
  }
  
  /**
   * Gets a list of all categories.
   * @return list of all categories.
   */
  def allCategorys: List[Category] = {
    return CategoryDao.allCategorys
  }

}