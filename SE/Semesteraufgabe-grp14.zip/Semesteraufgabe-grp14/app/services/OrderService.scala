package services

import dbaccess.OrderDao
import models.Order
import models.Additional
import models.Position

/**
 * Service class for order related operations.
 * 
 * @author safranek, krose
 */
object OrderService {
  
  /**
   * Adds a new order to the system.
   * @param userId Id of the user.
   * @return the new Order.
   */
  def newOrder(userId: Long): Order = {
    val newOrder = OrderDao.getDummy
    newOrder.user_id = userId
    return OrderDao.createOrder(newOrder)   
  }
  
    /**
   * Provides a filter option for the order management.
   * @param order a map of the orders.
   * @param orderBy the main category to order by.
   * @param item the id of the item to filter for.
   * @return Returns a map of orders filtered by the parameters.
   */
  
  def filter(order: Map[Long, List[Order]], orderBy: String, item: Long): Map[Long, List[Order]] = {
    var filteredOrder = scala.collection.mutable.Map[Long, List[Order]]()
    for((userId, ordersByUser) <- order) {
      var orderList = scala.collection.mutable.MutableList[Order]()
      for(order <- ordersByUser) {
    	orderBy match {
    	  case "filterUser" =>
    	    if(userId == item) {
    	    	orderList += order
    	    }
    	  case "filterCat" =>
    	    var hasProd = false
    	    for(pos <- order.positions) {
    	      if(pos.product.category == item) {
    	        hasProd = true
    	      }
    	    }
    	    if(hasProd) {
    	    	orderList += order
    	    }
    	  case "filterProd" =>
    	    var hasProd = false
    	    for(pos <- order.positions) {
    	      if(pos.product.id == item) {
    	        hasProd = true
    	      }
    	    }
    	    if(hasProd) {
    	    	orderList += order
    	    }
    	}
      }
      filteredOrder += (userId -> orderList.toList)
    }
    return filteredOrder.toMap
  }
  
    /**
   * Creates a position for the specified order.
   * @param order the order object to create a position for.
   * @param positionID the is of the position.
   * @param product product object.
   * @param unit the unit of measurement.
   * @param additionals a list of all additionals.
   * @return Returns the order.
   */
  def createPositionForOrder(order: Order, positionId: Long, product: models.Product, unit: Double, additionals: List[Additional]): Order = {
    
    var position = OrderDao.createPositionForOrder(order.id, positionId, product, unit, additionals)
    var positionList = scala.collection.mutable.MutableList[Position]()
    positionList ++= order.positions
    positionList += position
    order.setPositions(positionList.toList)
    return order
  }
  
  /**
   * Sets the total price for the order.
   * @param order the order object to set the new total for.
   * @return Returns the order.
   */
  def setTotalPrice(order: Order):Order = {
    var total:Double = 0;
    for(position <- order.positions) {
      total = total + position.price
    }
    return OrderDao.setTotal(order, total)
  }
  /**
   * Sets a new status for the order.
   * @param order the order object to set the new status for.
   * @return Returns the order.
   */
  def setStatus(orderId: Long, status: String):Order = {
    val order= getOrder(orderId)
    return OrderDao.setStatus(order, status)
  }
  /**
   * Gets an order.
   * @param orderId the database id of the order.
   * @return Returns the order.
   */
  def getOrder(orderId: Long): Order = {
    val order = OrderDao.getOrder(orderId)
    return order
  }
  /**
   * Returns whether there is a order placed that contains the specified product.
   * @param prodId the database id of the Product.
   * @return Returns whether the product is in an order.
   */
  def hasOrderForProduct(prodId: Long): Boolean = {
    val isUsed = OrderDao.hasOrderForProduct(prodId)
    return isUsed
  }
  
  /**
   * Gets orders ordered by user.
   * @param userName the name of the user.
   * @return Returns the order for the user.
   */
  def getOrdersForUser(userName: String): List[Order] = {
    val user = services.UserService.findUser(userName)
    return OrderDao.getOrderByUser(user);
  }
  /**
   * Gets all orders for a user.   
   * @return Returns an order map for the user.
   */
  def getOrdersByUser(): Map[Long, List[Order]] = {
    val users = services.UserService.registeredUsers
    var orderMap = scala.collection.mutable.Map[Long, List[Order]]()
    for(user <- users) {
      orderMap += (user.id -> getOrdersForUser(user.name))
    }
    return orderMap.toMap;
  }
}