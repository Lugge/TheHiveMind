package services

import dbaccess.UserDao
import models.User

/**
 * Service class for user related operations.
 * 
 * @author safranek, krose
 */
object UserService {
  
  /**
   * Adds a new user to the system.
   * @param name name of the new user.
   * @param password the password of the user.
   * @param postalCode the postal code of the user.
   * @param isAdmin states whether the user is an admin.
   * @param distance the distance of the users area to the shop.
   * @return the new user.
   */
  def addUser(name: String, password: String, postalCode: Int, isAdmin: Boolean, distance: Int): User = {
    // create User
    
    val newUser = User(-1, name, MD5.hash(password), postalCode, isAdmin, distance)
    
    // persist and return User
    return UserDao.addUser(newUser)   
  }
    /**
   * Edits a user.
   * @param id the database of the user.
   * @param name name of the new user.
   * @param password the password of the user.
   * @param postalCode the postal code of the user.
   * @param isAdmin states whether the user is an admin.
   * @return the new user.
   */
  def editUser (id: Long, name: String, password: String, postalCode: Int, isAdmin: Boolean): User =  {
    return UserDao.editUser(id, name: String, password: String, postalCode: Int, isAdmin: Boolean);
  }
  
  /**
   * Gets a list of all registered users.
   * @return list of users.
   */
  def registeredUsers: List[User] = {
    return UserDao.registeredUsers
  }
  /**
   * Gets a user map.
   * @return a map of users.
   */
  def getUserMapping(): Map[Long, String] = {
    var users = registeredUsers
    var userMap = scala.collection.mutable.Map[Long, String]()
    for (user <- users) {
      userMap += user.id -> user.name
    }
    return userMap.toMap
  }
  /**
   * Gets a dummy user.
   * @return returns a dummy user.
   */
  def getDummy: User = {
    return new User(0, "", "", 0, false, 0)
  }
  /**
   * Logs a user in.
   * @param name the name of the user to login.
   * @param password the password of the user to login.
   * @return whether the user was able to login.
   */
  def login(name: String, password: String): Boolean = {
    
    val loginUser = UserDao.getUserByName(name)
    if(MD5.hash(password) != loginUser.password) {
      return false
    }
    return true;
  }
  /**
   * Checks if the distance is at least 20 or over.
   * @param plz the postal code to check.
   * @return whether the distance is far enough.
   */
  def checkDistance(plz: Int): Boolean = {
    var distance = getDistance(plz) 
    controllers.UserController.lastDistance = distance
    return  distance <= 20
  }
  /**
   * Gets the distance of a location.
   * @param plz the postal code (not used yet).
   * @return the distance.
   */
  def getDistance(plz: Int): Int = {
    val r = scala.util.Random
    val distance = r.nextInt(50);
    return distance
  }
    /**
   * Gets the distance of a location.
   * @param plz the postal code.
   * @return the distance.
   */
  def checkUser(name: String): Boolean = {
    val checkUser = UserDao.getUserByName(name)
    if(checkUser.id == 0) {
      return true;
    }
    return false;
  }
    /**
   * Finds a user for the given name.
   * @param name the name of the user.
   * @return the user object.
   */
  def findUser(name: String) : User = {
    return UserDao.getUserByName(name);
  }
   /**
   * Gets a user via id.
   * @param userId the id of the user.
   * @return the distance.
   */
  def getUserById(userId: Long): User = {
    return UserDao.getUser(userId);
  }
}