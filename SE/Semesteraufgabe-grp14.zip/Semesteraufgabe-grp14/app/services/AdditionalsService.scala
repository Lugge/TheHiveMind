package services

import dbaccess.AdditionalsDao
import models.Additional

/**
 * Service class for additional related operations.
 * 
 * @author safranek, krose
 */
object AdditionalsService {
  
  /**
   * Adds a new additonal to the system.
   * @param name name of the new additional.
   * @param price the price of the additional.
   * @param category_id the category foreign_key of the additional.
   * @param isAvailable the state of availability of the additional.
   * @return the new additonal.
   */
  def addAdditional(name: String, price: Double, category_id: Long, isAvailable: Boolean): Additional = {
    val newAdditional = Additional(-1, name, price, category_id, isAvailable)
    // persist and return Product
    return AdditionalsDao.addAdditional(newAdditional)   
  }
  
  /**
   * Deletes an additional.
   * @param id the id of the additional.
   */
  def deleteAdditional(id: Long) = {
    // persist and return Product
    AdditionalsDao.deleteAdditional(id)   
  }
  
  /**
   * Gets a list of all additonals.
   * @return list of additionals.
   */
  def allAdditionals: List[Additional] = {
    return AdditionalsDao.allAdditionals
  }
  /**
   * Gets an additonal.
   * @return the additional object.
   */  
  def getAdditional(additionalId: Long): Additional = {
    return AdditionalsDao.getAdditional(additionalId)
  }
  
    /**
   * Gets a list of all additonals ordered by category.
   * @return list of additionals ordered by category.
   */
  def allAdditionalsOrderByCategory(): Map[String, List[Additional]] = {
    return AdditionalsDao.allAdditionalsOrderByCategory
  }
}