package services

import dbaccess.ProductDao
import models.Product

/**
 * Service class for product related operations.
 * 
 * @author safranek, krose
 */
object ProductService {
  
  /**
   * Adds a new product to the system.
   * @param name name of the new product.
   * @param price the price of the product.
   * @param category the category foreign_key of the product.
   * @param unit the unit of measurement of the product.
   * @param isAvailable the state of availability of the product.
   * @param states whether the product is deactivated.
   * @return the new product.
   */
  def addProduct(name: String, price: Double, category: Long, unit: String, isAvailable: Boolean, isDeactivated: Boolean): Product = {
    val newProduct = Product(-1, name, price, category, unit, isAvailable, isDeactivated)
    // persist and return Product
    return ProductDao.addProduct(newProduct)   
  }
  
  /**
   * Edits products.
   * @param id of the product; .
   * @return the new user.
   */
  def editProduct(id: Long, name: String, price: Double, category: Long, unit: String, isAvailable: Boolean) = {
    ProductDao.editProduct(id: Long, name: String, price: Double, category: Long, unit: String, isAvailable: Boolean)
     
  }

  /**
   * Deletes/Deactivates a Product.
   * @param id of the product.
   * 
   */
  def deleteProduct(id: Long) = {
    
    ProductDao.deleteProduct(id)   
  }
  
  /**
   * Gets a list of all registered users.
   * @return list of users.
   */
  def allProducts: List[Product] = {
    return ProductDao.allProducts
  }
  
  /**
   * Gets all Products ordered by a category.
   * @return Returns all products ordered by category.
   */
  def allProductsOrderByCategory(): Map[String, List[Product]] = {
    return ProductDao.allProductsOrderByCategory
  }

  def getProduct(productId: Long): Product = {
    return ProductDao.getProduct(productId)
  }
  /**
   * Returns whether there is a product placed in the category.
   * @param categoryId the database id of the Category.
   * @return Returns whether the category has in a product.
   */
  def hasProductForCategory(categoryId: Long): Boolean = {
    return ProductDao.hasProductForCategory(categoryId)
  }
}