package dbaccess

import anorm._
import play.api.Play.current
import play.api.db._
import anorm.NamedParameter.symbol
import models.Product

/**
 * Data access object for product related operations.
 * 
 * @author lk, js
 */
object ProductDao {

  /**
   * Creates the given Product in the database.
   * @param product the product object to be stored.
   * @return the persisted product object 
   */
  def addProduct(product: Product): Product = {
    DB.withConnection { implicit c =>
      val id: Option[Long] =
        SQL("insert into Products(name, price, category_id, unit, isAvailable, isDeactivated) values ({name}, {price}, {category}, {unit}, {isAvailable}, {isDeactivated})").on(
          'name -> product.name, 'price -> product.price, 'category -> product.category, 'unit -> product.unit, 'isAvailable -> product.isAvailable, 'isDeactivated -> false).executeInsert()
      product.id = id.get
    }
    return product
  }
  
  /**
   * Edits the given product 
   * @param id The id of the product
   * @param name The name to be set
   * @param price The price to be set.
   * @param unit The unit to be set.
   * @param isAvailable Indicates if the product is available
   * @return the altered product
   */
  def editProduct(id: Long, name: String, price: Double, category: Long, unit: String, isAvailable: Boolean): Product = {

    DB.withConnection { implicit c =>     
    		   
        SQL("Update Products set name={name}, price={price}, category_id={category}, unit={unit}, isAvailable={isAvailable} where id = "+ id).on(
          'name -> name, 'price -> price, 'category -> category, 'unit -> unit, 'isAvailable -> isAvailable).executeInsert()
         val prod = getProduct(id)
         return prod;      
    }   

  }
  
  
  /**
   * Deletes a product from the database.
   * If an order contains this product it is only deactivated. 
   * @param id the id of the product to be deleted.
   */
  def deleteProduct(id: Long) = {
    if(id != 0) {
    	val isInUse = services.OrderService.hasOrderForProduct(id);
    	if (!isInUse) {
    	  
    		DB.withConnection { implicit c =>     
    		   
	        SQL("Update Products set isDeactivated={isDeactivated} where id = {id}").on(
	          'isDeactivated -> true, 'id -> id).executeInsert()
    		}   
    	} else {
		    DB.withConnection { implicit c =>
		      SQL("delete from Products where id = {id}").on(
		          'id -> id).executeUpdate()
		    }
    	}		    
    }
  }
  
  /**
   * Deletes products by category.
   * @param id the category id.
   */
  def deleteProductsByCategory(id: Long) = {
    val products = getProductsByCategory(id) 
     for (product <- products) {
       deleteProduct(product.id)
     } 
  }

  /**
   * Returns all products mapped to their category.
   * @return A map in the form of [Categoryname, List[Product]] 
   */
  def allProductsOrderByCategory(): Map[String, List[Product]] = {
    var categorys = CategoryDao.allCategorys
    var productMap = scala.collection.mutable.Map[String, List[Product]]()
    
    for(category <- categorys) {
      productMap += (category.name -> getProductsByCategory(category.id))
    }
    
    return productMap.toMap
  }
  
  /**
   * Returns all products for a specific category
   * @param id the id of the category.
   * @return A list of products
   */
  def getProductsByCategory(id: Long): List[Product] = {
    DB.withConnection { implicit c =>
      val productsByCat = SQL("Select * from Products where category_id = "+ id +";")
      val products = productsByCat().map(row => Product(row[Long]("id"), row[String]("name"), row[Double]("price"), row[Long]("category_id"), row[String]("unit"), row[Boolean]("isAvailable"), row[Boolean]("isDeactivated"))).toList
      return products;
    }
  }
  
  /**
   * Returns a list of all Products from the database.
   * @return a list of product objects.
   */
  def allProducts: List[Product] = {
    DB.withConnection { implicit c =>
      val allProducts = SQL("Select * from Products;")
      val products = allProducts().map(row => Product(row[Long]("id"), row[String]("name"), row[Double]("price"), row[Long]("category_id"), row[String]("unit"), row[Boolean]("isAvailable"), row[Boolean]("isDeactivated"))).toList
      return products;
    }
  }
  
  /**
   * Returns a single product from the database
   * @param productId the id of the product
   * @return the product object 
   */
  def getProduct(productId: Long): Product = {
    DB.withConnection { implicit c =>
	    val productTmp = SQL("Select * from Products where id = " + productId + ";").apply().head
	    val product = new Product (productTmp[Long]("id"),productTmp[String]("name"),productTmp[Double]("price"), productTmp[Long]("category_id"), productTmp[String]("unit"), productTmp[Boolean]("isAvailable"), productTmp[Boolean]("isDeactivated"))
	    return product
    }
  }
  
  /**
   * Checks if a product is used in a category.
   * @param Id of the category
   * @return true for has category
   */
  def hasProductForCategory(categoryId: Long): Boolean = {
   try {
     DB.withConnection { implicit c =>
	   val allOrders = SQL("Select * from Products where category_id = " + categoryId + ";").apply().head   
	   return false
     }
	   
   }catch{
     
	   case e: Exception => return true
   }
  }
}