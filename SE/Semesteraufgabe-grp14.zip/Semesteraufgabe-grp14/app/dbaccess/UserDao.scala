package dbaccess

import anorm._
import play.api.Play.current
import play.api.db._
import anorm.NamedParameter.symbol
import models.User
import services.MD5

/**
 * Data access object for user related operations.
 * 
 * @author lk, js
 */
object UserDao {

  /**
   * Creates the given user in the database.
   * @param user the user object to be stored.
   * @return the persisted user object 
   */
  def addUser(user: User): User = {
    DB.withConnection { implicit c =>
      val id: Option[Long] =
        SQL("insert into User(name, password, postalCode, isAdmin, distance) values ({name}, {password}, {postalCode}, {isAdmin}, {distance})").on(
          'name -> user.name, 'password -> user.password, 'postalCode -> user.postalCode, 'isAdmin -> user.isAdmin, 'distance -> user.distance).executeInsert()
      user.id = id.get
    }
    return user
  }
  
  /**
   * Edits the user in the database.
   * @param userId The id of the user.
   * @param name The name to be set.
   * @param password The password to be set.
   * @param postalcode The postal code to be set.
   * @param isAdmin Indicates if the user is an admin.
   * @return the altered user object 
   */
  def editUser(userId: Long, name: String, password: String, postalCode: Int, isAdmin: Boolean): User = {
    DB.withConnection { implicit c =>
      val checkUser = getUser(userId)
      var pw = MD5.hash(password)
      if(password == "") {
        pw = checkUser.password 
      }
	    val id: Option[Long] =
        SQL("Update User set name={name}, password={password}, postalCode={postalCode}, isAdmin={isAdmin} where id = "+ userId).on(
          'name -> name, 'password -> pw, 'postalCode -> postalCode, 'isAdmin -> isAdmin).executeInsert()
          val user = getUser(userId)
          return user;
    }
  }
  
  /**
   * Returns a user by id.
   * @param id the user id.
   * @return the user object 
   */
  def getUser(id: Long): User = {
    DB.withConnection { implicit c =>
	    val userTmp = SQL("Select * from User where id = " + id + ";").apply().head
	    val user = new User (userTmp[Long]("id"), userTmp[String]("name"), userTmp[String]("password"), userTmp[Int]("postalCode"), userTmp[Boolean]("isAdmin"), userTmp[Int]("distance"))
	    return user
    }    
  }
  
  /**
   * Returns an user by name.
   * @param name The user name.
   * @return The user object 
   */
  def getUserByName(name: String): User = {
    try {
	    DB.withConnection { implicit c =>
	      
		    val userTmp = SQL("Select * from User where name = '" + name + "' ;").apply().head
		    val user = new User (userTmp[Long]("id"), userTmp[String]("name"), userTmp[String]("password"), userTmp[Int]("postalCode"), userTmp[Boolean]("isAdmin"), userTmp[Int]("distance"))
	
		    return user
	    }    
    }
    catch{
      case e: Exception => return new User(0, "", "", 0, false, 0) 
    }
  }
  

  /**
   * Returns a list of available user from the database.
   * @return a list of user objects.
   */
  def registeredUsers: List[User] = {
    DB.withConnection { implicit c =>
      val selectUsers = SQL("Select * from User;")
      val users = selectUsers().map(row => User(row[Long]("id"), row[String]("name"), row[String]("password"), row[Int]("postalCode"), row[Boolean]("isAdmin"), row[Int]("distance"))).toList
      return users;
    }
  }

}