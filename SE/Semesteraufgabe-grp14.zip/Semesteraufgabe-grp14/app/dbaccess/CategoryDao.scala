package dbaccess

import anorm._
import play.api.Play.current
import play.api.db._
import anorm.NamedParameter.symbol
import models.Category

/**
 * Data access object for category related operations.
 * 
 * @author lk, js
 */
object CategoryDao {

  /**
   * Creates the given category in the database.
   * @param category the category object to be stored.
   * @return the persisted category object 
   */
  def addCategory(category: Category): Category = {
    DB.withConnection { implicit c =>
      val id: Option[Long] =
        SQL("insert into ProductCategory (name, isDeactivated) values ({name}, {isDeactivated})").on(
          'name -> category.name, 'isDeactivated -> false).executeInsert()
      category.id = id.get
    }
    return category
  }
  
  /**
   * Deletes the given category from database.
   * @param category the category id to be deleted.
   */
  def deleteCategory(id: Long) = {
    if(id != 0) {
      ProductDao.deleteProductsByCategory(id)
    	if (!services.ProductService.hasProductForCategory(id)) {
    		DB.withConnection { implicit c =>     
	        SQL("Update ProductCategory set isDeactivated={isDeactivated} where id = {id}").on(
	          'isDeactivated -> true, 'id -> id).executeInsert()
    		}
    	}else {
		    DB.withConnection { implicit c =>
		      SQL("delete from ProductCategory  where id = {id}").on(
		          'id -> id).executeUpdate()
		    }
    	}
    }
  }
  
  

  /**
   * Returns a list of all categories from the database.
   * @return a list of category objects.
   */
  def allCategorys: List[Category] = {
    DB.withConnection { implicit c =>
      val allCategorys = SQL("Select id, name, isDeactivated from ProductCategory ;")
      val categorys = allCategorys().map(row => Category(row[Long]("id"), row[String]("name"), row[Boolean]("isDeactivated"))).toList
      var retCats = scala.collection.mutable.MutableList[Category]()
      for(cat <- categorys) {
        if(!cat.isDeactivated) {
          retCats += cat
        }
      }
      return retCats.toList;
    }
  }

}