package dbaccess

import anorm._
import play.api.Play.current
import play.api.db._
import anorm.NamedParameter.symbol
import models.Order
import models.User
import models.Additional
import models.Position
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Data access object for order related operations.
 * 
 * @author lk, js
 */
object OrderDao {

  /**
   * Creates the given Order in the database.
   * @param order the order object to be stored.
   * @return the persisted order object 
   */
  def createOrder(order: Order): Order = {
    var user = services.UserService.getUserById(order.user_id)
    val format = new SimpleDateFormat("dd-MM-yyyy HH:mm")
    val order_date = format.format(Calendar.getInstance().getTime())
    order.duration = getDuration(user.distance);
    order.status = "eingegangen"
    DB.withConnection { implicit c =>
      val id: Option[Long] =
        SQL("insert into Orders(user_id, order_date, duration, status) values ({user}, {date}, {duration}, {status});").on(
          'user -> order.user_id, 'date -> order_date.toString(), 'duration -> order.duration, 'status -> order.status).executeInsert()
      
      order.id = id.get
      order.order_date = order_date.toString()
    }
    return order
  }
  
  /**
   * Dummy function to return the duration for a specific distance.
   * @param distance The distance to the pizza shop.
   * @return A random value that represents the duration
   */
  def getDuration (distance: Int): Int = {
    var duration = distance + 10;
    val r = scala.util.Random
    val rnd = r.nextInt(15);
    duration = duration + rnd
    return duration
  }
  /**
   * Checks if a product is used in an order.
   * @param Id of the prod
   * @return true for hasOrder false for no order
   */
  def hasOrderForProduct(prodId: Long): Boolean = {
		  
       try {
         DB.withConnection { implicit c =>
    	   val allOrders = SQL("Select * from Order_Positions where product_id = " + prodId + ";").apply().head
    	   
    	   return false
         }
    	   
       }catch{
         
    	   case e: Exception => return true;
       }
      return false    
  }
  

  /**
   * Updates the status of an order
   * @param order The order object to be updated.
   * @param status The status to be set.
   * @return the updated order object 
   */

  def setStatus(order: Order, status: String):Order ={
    DB.withConnection { implicit c =>
        SQL("Update Orders set status = {status} where id="+ order.id +";").on(
          'status -> status).executeUpdate()
      
      order.status = status
    }
    return order
  }
  
  /**
   * Updates the total price of an order
   * @param order The order object to be updated.
   * @param total The price to be set.
   * @return the updated order object 
   */
  def setTotal(order: Order, total: Double): Order = {
    DB.withConnection { implicit c =>
        SQL("Update Orders set total = {total} where id="+ order.id +";").on(
          'total -> total).executeUpdate()
      
      order.total = total
    }
    return order
  }
  
  
  /**
   * Returns a list of all Orders from the database for a specific User.
   * @param user a User Object
   * @return a list of order objects.
   */
  def getOrderByUser(user: User): List[Order] = {
    DB.withConnection { implicit c =>
      val allOrders = SQL("Select * from Orders where user_id = " + user.id + ";")
      val orders = allOrders().map(row => new Order(row[Long]("id"), row[Long]("user_id"), row[Double]("total"), row[String]("order_date"), row[Int]("duration"), row[String]("status"))).toList
      for (order <- orders) {
        order.setPositions(getPositionsForOrder(order));
      }
      return orders;
    }
  }
  
  /**
   * Returns a specific order object.
   * @param orderId The id of the order.
   * @return the order object 
   */
  def getOrder(orderId: Long): Order = {
    DB.withConnection { implicit c =>
	    val orderTmp = SQL("Select * from Orders where id = " + orderId + ";").apply().head
	    val order = new Order (orderTmp[Long]("id"), orderTmp[Long]("user_id"), orderTmp[Double]("total"), orderTmp[String]("order_date"), orderTmp[Int]("duration"), orderTmp[String]("status")) 
	    order.setPositions(getPositionsForOrder(order));
	    return order
    }
  }
  
  /**
   * Returns all positions of a specific order
   * @param order The order object.
   * @return a list of positions objects
   */
  def getPositionsForOrder (order: Order): List[Position] = {
    DB.withConnection { implicit c =>
      val allPositionsForOrder = SQL("Select * from Order_Positions where order_id = " + order.id + ";")
      val PositionsForOrder = allPositionsForOrder().map(row => Position(row[Long]("position_id"), services.ProductService.getProduct(row[Long]("product_id")), row[Double]("price"), row[Double]("unit"), getAdditionalsForPosition(row[Long]("id")))).toList;
      return PositionsForOrder;
    }
  }
  
  /**
   * Returns the additionals for a specific position
   * @param positionId The id of the position
   * @return A list of additionals  
   */
  def getAdditionalsForPosition(positionId: Long): List[Additional] = {
    DB.withConnection { implicit c =>
      val allAdditionalsForPosition = SQL("Select additionals_id from Product_Additionals where order_position_id = " + positionId + ";")
      val additionalsForPosition = allAdditionalsForPosition().map(row => AdditionalsDao.getAdditional(row[Long]("additionals_id"))).toList;
      
      return additionalsForPosition;
    }
  }
  
  /**
   * Creates a position for an order 
   * @param orderId The id of the order
   * @param positionId The number of the position in the position list.
   * @param product The product for this position.
   * @param unit The amount the person wants to have
   * @param additionals The list of additionals for this position
   * @return the persisted position
   */
  def createPositionForOrder(orderId: Long, positionId: Long, product: models.Product, unit: Double, additionals: List[Additional]): Position = {
    DB.withConnection { implicit c =>
      var total = product.price * unit
      
      for(additional <- additionals) {          
          total += additional.price
      }
      
        val id: Option[Long] =
        SQL("insert into Order_Positions(order_id, position_id, product_id, price, unit) values ({order}, {position}, {product}, {price}, {unit})").on(
          'order -> orderId, 'position -> positionId, 'product -> product.id, 'price -> total, 'unit -> unit).executeInsert()
      createAdditionalsForPosition(id.get, additionals)
      var position = Position (id.get, product, total, unit, additionals)
      return position
    }    
  }
  
  
  /**
   * Creates the additionals for a position.
   * @param orderPositionId The id of the position
   * @param additionals The list of additionals for this position
   */
  def createAdditionalsForPosition(orderPositionId: Long, additionals: List[Additional]) {
    DB.withConnection { implicit c =>      
      for(additional <- additionals){
		  val id: Option[Long] =
		  	SQL("insert into Product_Additionals(order_position_id, additionals_id) values ({order_position_id}, {additionals_id})").on(
		  			'order_position_id -> orderPositionId, 'additionals_id -> additional.id).executeInsert()
      }  
    }
  }
  
  /**
   * Returns an empty dummy order
   * @return an empty order
   */
  def getDummy(): Order = {
    return new Order(0, 0, 0, "", 0, "")
  }
}