package dbaccess

import anorm._
import play.api.Play.current
import play.api.db._
import anorm.NamedParameter.symbol
import models.Additional

/**
 * Data access object for additionals related operations.
 * 
 * @author lk, js
 */
object AdditionalsDao {

  /**
   * Creates the given Additional in the database.
   * @param additional the additional object to be stored.
   * @return the persisted additional object 
   */
  def addAdditional(additional: Additional): Additional = {
    DB.withConnection { implicit c =>
      val id: Option[Long] =
        SQL("insert into Additionals(name, price, category_id, isAvailable) values ({name}, {price}, {category_id}, {isAvailable})").on(
          'name -> additional.name, 'price -> additional.price, 'category_id -> additional.category_id, 'isAvailable -> additional.isAvailable).executeInsert()
      additional.id = id.get
    }
    return additional
  }
  
  /**
   * Deletes the given Additional from the System.
   * @param additional the additional object to be stored.
   */
  def deleteAdditional(id: Long) = {
    if(id != 0) {
	    DB.withConnection { implicit c =>
	      SQL("delete from Additionals where id = {id}").on(
	          'id -> id).executeUpdate()
	    }
    }
  }
  
  /**
   * Returns a list of all additionals from the database.
   * @return a list of additional objects.
   */
  def allAdditionals: List[Additional] = {
    DB.withConnection { implicit c =>
      val allAdditionals = SQL("Select * from Additionals;")
      val additionals = allAdditionals().map(row => Additional(row[Long]("id"), row[String]("name"), row[Double]("price"), row[Long]("category_id"), row[Boolean]("isAvailable"))).toList
      return additionals;
    }
  }
  
  /**
   * Returns a single additional by id from the database.
   * @param Long The id of the additional
   * @return an additional object.
   */
  def getAdditional(additionalId: Long): Additional = {
    DB.withConnection { implicit c =>
	    val additionalTmp = SQL("Select * from Additionals where id = " + additionalId + ";").apply().head
	    val additional = new Additional (additionalTmp[Long]("id"),additionalTmp[String]("name"),additionalTmp[Double]("price"), additionalTmp[Long]("category_id"), additionalTmp[Boolean]("isAvailable"))
	    return additional
    }
  }
  
  /**
   * Returns a List of additionals, ordered by their category.
   * @return a Map in the Form of [Categoryname, List[Additional]]
   */
  def allAdditionalsOrderByCategory(): Map[String, List[Additional]] = {
    var categorys = CategoryDao.allCategorys
    var additionalsMap = scala.collection.mutable.Map[String, List[Additional]]()
    
    for(category <- categorys) {
      additionalsMap += (category.name -> getAdditionalsByCategory(category.id))
    }
    
    return additionalsMap.toMap
  }

  /**
   * Returns a list of additionals filtered by categories.
   * @param Long The id of the category
   * @return a list of additionals
   */  
  def getAdditionalsByCategory(id: Long): List[Additional] = {
    DB.withConnection { implicit c =>
      val additionalsByCat = SQL("Select * from Additionals where category_id = "+ id +";")
      val additionals = additionalsByCat().map(row => Additional(row[Long]("id"), row[String]("name"), row[Double]("price"), row[Long]("category_id"), row[Boolean]("isAvailable"))).toList
      return additionals;
    }
  }
}