package forms

/**
 * Form containing data to edit a products.
 * @param the id of the product to be edited.
 * @param name the name of the product. 
 * @param price the price of the product. 
 * @param category the database category_id foreign key.
 * @param unit the unit of measurement of the product. 
 * @param isAvailableAdd the state of availability of the additional.
 */
case class EditProductForm(id: Long, name: String, price: Double, category: Long, unit: String, isAvailable: Boolean);