package forms


/**
 * Form containing data to create an additionalform for orders .
 * @param id of the form.
 */
case class CreateOrderFormAdditional(id: Long) 