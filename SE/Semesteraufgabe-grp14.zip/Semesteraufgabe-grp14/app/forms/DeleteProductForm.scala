package forms

/**
 * Form containing data to delete a Product.
 * @param id of the Product.
 */
case class DeleteProductForm(id: Long) 