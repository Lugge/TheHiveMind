package forms

/**
 * Form containing data to create a product.
 * @param name the name of the product. 
 * @param price the price of the product. 
 * @param category the database category id foreign key. 
 * @param isAvailableAdd the state of availability of the product.
 * @param isDeactivated states whether the product is deactivated.
 */
case class CreateProductForm(name: String, price: Double, category: Long, unit: String, isAvailable: Boolean, isDeactivated: Boolean) 