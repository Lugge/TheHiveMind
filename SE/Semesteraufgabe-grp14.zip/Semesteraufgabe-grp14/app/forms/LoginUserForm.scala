package forms

/**
 * Form containing data to login a user.
 * @param name the name of the user.
 * @param password the password of the user.
 */
case class LoginUserForm(name: String, password: String) 