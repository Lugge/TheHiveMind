package forms

/**
 * Form containing data to filter the ordermanagement.
 * @param orderBy the order-type by which to order.
 * @param item the id of chosen filter attribute based on orderBy.
 */
case class FilterForm(orderBy: String, item: Long);