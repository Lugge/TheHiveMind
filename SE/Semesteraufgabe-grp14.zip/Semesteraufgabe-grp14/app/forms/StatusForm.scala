package forms

/**
 * Form containing data for the order status view.
 * @param id the database id of the order(for setting the status)
 * @param status the status of the Product.
 */
case class StatusForm(id: Long, status: String) 