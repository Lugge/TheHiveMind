package forms

/**
 * Form containing data to create a Extras.
 * @param name the name of the additional. 
 * @param price the price of the additional. 
 * @param category_id the database category_id foreign key. 
 * @param isAvailableAdd the state of availability of the additional.
 */
case class CreateAdditionalsForm(name: String, price: Double, category_id: Long, isAvailableAdd: Boolean) 