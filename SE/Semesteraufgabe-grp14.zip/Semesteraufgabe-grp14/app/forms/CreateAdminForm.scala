package forms

/**
 * Form containing data to create an admin-user.
 * @param name the name of the user. 
 * @param password the password of the user. 
 * @param postalcode the postal code of the user. 
 * @param isAdmin states if the user will receive admin rights.
 */
case class CreateAdminForm(name: String, password: String, postalcode:Int, isAdmin: Long);