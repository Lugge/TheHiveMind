package forms

/**
 * Form containing data to edit n user.
 * @param id the database id of the user.
 * @param name the name of the user. 
 * @param password the password of the user. 
 * @param postalcode the postal code of the user. 
 * @param isAdmin states if the user will receive admin rights.
 */
case class EditUserForm(id: Long, name: String, password: String, postalcode:Int, isAdmin: Boolean);