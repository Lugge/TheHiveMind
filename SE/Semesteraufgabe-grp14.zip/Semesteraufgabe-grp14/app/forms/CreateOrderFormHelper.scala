package forms


/**
 * Form containing data to create a Helper Order Form.
 * @param user_id the database user_id of the FormHelper.
 * @param order contents list of the products in the order.
 */
case class CreateOrderFormHelper(user_id: Long, orderContents: List[CreateOrderForm]) 