package forms

/**
 * Form containing data to delete an additional.
 * @param id of the additional.
 */
case class DeleteAdditionalsForm(id: Long) 