package forms

/**
 * Form containing data to delete a category.
 * @param id of the category.
 */
case class DeleteCategoryForm(id: Long) 