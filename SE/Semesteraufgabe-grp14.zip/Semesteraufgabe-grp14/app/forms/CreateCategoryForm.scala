package forms

/**
 * Form containing data to create a Category.
 * @param name name of the Category.
 */
case class CreateCategoryForm(name: String) 