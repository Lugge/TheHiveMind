package forms

/**
 * Form containing data to create a user.
 * @param name the name of the user.
 * @param password the password of the user.
 * @param postalcode the postalcode of the user.
 */
case class CreateUserForm(name: String, password: String, postalcode:Int);