package forms

/**
 * Form containing data to create an order.
 * @param position the database position id. 
 * @param id the order of the order. 
 * @param unit the unit of measurement of the order. 
 * @param additionals a List of additionals of the order.
 */
case class CreateOrderForm(position: Int, id: Long, unit:Double, additionals: List[CreateOrderFormAdditional]) 