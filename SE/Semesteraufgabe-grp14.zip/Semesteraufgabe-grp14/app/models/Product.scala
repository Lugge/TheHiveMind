package models
/**
 * product entity.
 * @param id database id of the product.
 * @param name name of the product. 
 * @param price price of the product.
 * @param category the database category foreign_key of the product.
 * @param unit the unit of measurement of the product.
 * @param isAvailable the state of availability of the product.
 * @param isDeactivated indicates if a product is deactivated.
 */
case class Product (var id: Long, var name: String, var price: Double, var category: Long, var unit: String, var isAvailable: Boolean, var isDeactivated: Boolean)