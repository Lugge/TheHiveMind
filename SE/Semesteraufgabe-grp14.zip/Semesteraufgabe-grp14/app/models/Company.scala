package models

/**
 * company entity (name).
 * 
 * 
 */
object Company {

  val name = "Pizza-Flitza"
  
}