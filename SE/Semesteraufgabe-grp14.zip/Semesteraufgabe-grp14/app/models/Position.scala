package models
/**
 * position entity.
 * @param id database id of the position.
 * @param product the product object of the position. 
 * @param price the price of the position.
 * @param unit the unit of measurement of the position.
 * @param additionals a List of all additionals for the position.
 * 
 * @author safranek, krose
 */
case class Position (var id: Long, product: Product, price: Double, unit: Double, additionals: List[Additional])
