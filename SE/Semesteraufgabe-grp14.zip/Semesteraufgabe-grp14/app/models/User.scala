package models

/**
 * User entity.
 * @param id database id of the user.
 * @param name name of the user.
 */
case class User(var id: Long, var name: String, var password:String, var postalCode: Int, var isAdmin: Boolean, var distance: Int) 