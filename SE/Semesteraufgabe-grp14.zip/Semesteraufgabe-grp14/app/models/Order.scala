package models
/**
 * order entity.
 * @param id database id of the order.
 * @param user_id the database user_id foreign key of the order.
 * @param total the total price of the order. 
 * @param order_date the date of the order.
 * @param duration the duration of the delivery for the order.
 * @param status the delivery status of the order.
 */
class Order (var id: Long, var user_id:Long, var total: Double, var order_date: String, var duration: Int, var status: String)
{
  var positions = List[Position]()
    
  def setPositions (positionParam: List[Position])
  { 
    positions = positionParam;
  }
}
