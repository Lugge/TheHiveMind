package models
/**
 * additional entity.
 * @param id database id of the Additional.
 * @param name name of the Additional. 
 * @param price price of the Additional.
 * @param category_id the database category foreign_key of the Additional.
 * @param isAvailable the state of availability of the Additional.
 */
case class Additional (var id: Long, var name: String, var price: Double, var category_id: Long, var isAvailable: Boolean)