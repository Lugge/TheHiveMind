package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import models._

/**
 * Main controller of the Pizza Service application.
 * 
 * @author ob, scs, lk, js
 */
object Application extends Controller {

  /**
   * Shows the registration page of the application.
   */
  def registration = Action { request =>
    request.session.get("user").map{ user =>
        Ok(views.html.registration(controllers.UserController.userForm, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
       Ok(views.html.registration(controllers.UserController.userForm, services.UserService.getDummy))
    }    
  }
  
  /**
   * Shows the management overview.
   */
  def manage = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.manage(services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
       Ok(views.html.manage(services.UserService.getDummy))
    }
  }
  
  /**
   * Shows the order view, the contents of a single order.
   * 
   *  @param orderId Long: The id of the order 
   */
  def showOrder(orderId: Long) = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.showOrder(services.OrderService.getOrder(orderId), controllers.OrderController.setStatusForm, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
       Ok(views.html.showOrder(services.OrderService.getOrder(orderId), controllers.OrderController.setStatusForm, services.UserService.getDummy))
    }
  }
  
  /**
   * Shows the overview page over all orders by user.
   */
  def myOrders()= Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.myOrders(services.UserService.findUser(user), services.OrderService.getOrdersForUser(user))).withSession("user" -> user)
    }.getOrElse{
       Ok(views.html.myOrders(services.UserService.getDummy, List[Order]()))
    }
  }
  
  /**
   * Shows the order page of the application.
   */
  def order = Action { request =>
    request.session.get("user").map{ user =>
        Ok(views.html.order(controllers.OrderController.orderForm, services.ProductService.allProductsOrderByCategory, services.UserService.findUser(user), services.AdditionalsService.allAdditionalsOrderByCategory)).withSession("user" -> user)
    }.getOrElse{
         Ok(views.html.order(controllers.OrderController.orderForm, services.ProductService.allProductsOrderByCategory, services.UserService.getDummy, services.AdditionalsService.allAdditionalsOrderByCategory))
    }
  }
  
  /**
   * Shows the product management page of the application.
   */  
  def productManager = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.getDummy))
    }
  }
  
  /**
   * Shows the category management page of the application.
   */
  def categoryManager = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.categoryManager(controllers.CategoryController.categoryForm, services.CategoryService.allCategorys, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.categoryManager(controllers.CategoryController.categoryForm, services.CategoryService.allCategorys, services.UserService.getDummy))
    }
  }
  
  
  /**
   * Shows the edit page to edit a specific user.
   * 
   * @param id Long: Id of the user
   */
  def showEditUser(userID: Long) = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.editUser(controllers.UserController.editUserForm, services.UserService.getUserById(userID), services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.editUser(controllers.UserController.editUserForm, services.UserService.getUserById(userID), services.UserService.getDummy))
    }
  }
  

  def showEditProduct(productID: Long) = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.editProduct(controllers.ProductController.editProductForm, services.ProductService.getProduct(productID), services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.editProduct(controllers.ProductController.editProductForm, services.ProductService.getProduct(productID), services.UserService.getDummy))
    }
  }
  
  

  /**
   * Shows the start page of the application.
   */

  def index = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.index(services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.index(services.UserService.getDummy))
    }
  }
  
  /**
   * Shows the order management page of the application.
   */
  def orderManager = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.orderManagement(controllers.OrderController.filterForm, services.OrderService.getOrdersByUser, services.UserService.getUserMapping, services.UserService.findUser(user), services.CategoryService.allCategorys, services.ProductService.allProducts)).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.orderManagement(controllers.OrderController.filterForm, services.OrderService.getOrdersByUser, services.UserService.getUserMapping, services.UserService.getDummy, services.CategoryService.allCategorys, services.ProductService.allProducts))
    }
  }
  
  /**
   * Filters the order management.
   */
  def filterApp = Action { implicit request =>
    controllers.OrderController.filterForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        BadRequest(views.html.orderManagement(formWithErrors, services.OrderService.getOrdersByUser, services.UserService.getUserMapping, services.UserService.findUser(user), services.CategoryService.allCategorys, services.ProductService.allProducts)).withSession("user" -> user)
        	}.getOrElse{
    	BadRequest(views.html.orderManagement(formWithErrors, services.OrderService.getOrdersByUser, services.UserService.getUserMapping, services.UserService.getDummy, services.CategoryService.allCategorys, services.ProductService.allProducts))
        	}
      },
      orderData => {
	    Redirect(routes.Application.showFilter(orderData.orderBy, orderData.item))
      }      
    )   
   }
  
  /**
   * Shows the filtered order management page.
   */  
  def showFilter(orderBy: String, item: Long) = Action { request =>
		var order = services.OrderService.getOrdersByUser
	    order = services.OrderService.filter(order, orderBy, item)
		request.session.get("user").map{ user =>
	    Ok(views.html.orderManagement(controllers.OrderController.filterForm, order, services.UserService.getUserMapping, services.UserService.findUser(user), services.CategoryService.allCategorys, services.ProductService.allProducts)).withSession("user" -> user)
	    }.getOrElse{
	      Ok(views.html.orderManagement(controllers.OrderController.filterForm, order, services.UserService.getUserMapping, services.UserService.getDummy, services.CategoryService.allCategorys, services.ProductService.allProducts))
	    }
	}

  /**
   * Logs out and displays the main page.
   */
  def logout = Action {
    Ok(views.html.index(services.UserService.getDummy)).withNewSession
  }
  
  /**
   * Error page of the application.
   */
  def error = Action {request =>
    request.session.get("user").map{ user =>
        Ok(views.html.error(services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.error(services.UserService.getDummy))
    }
  }
}