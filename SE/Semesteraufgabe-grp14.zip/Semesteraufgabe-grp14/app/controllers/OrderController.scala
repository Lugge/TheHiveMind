package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import models._
import services.OrderService
import forms.CreateOrderForm
import forms.CreateOrderFormHelper
import forms.CreateOrderFormAdditional
import forms.StatusForm
import forms.FilterForm

/**
 * Controller for order specific operations.
 * 
 * @author lk, js
 */
object OrderController extends Controller {

  /**
   * Form object for order data.
   */
 val orderForm: Form[CreateOrderFormHelper] = Form(
    mapping(
      "user_id" -> longNumber,
      "orderContents" -> list(mapping(
          "position" -> number,
          "id" -> longNumber,
          "unit" -> of[Double],
          "additionals" -> list(mapping(
              "id" -> longNumber
              )(CreateOrderFormAdditional.apply)(CreateOrderFormAdditional.unapply))
          )(CreateOrderForm.apply)(CreateOrderForm.unapply))
    )(CreateOrderFormHelper.apply)(CreateOrderFormHelper.unapply)
)

  /**
   * Form object for filtering the order manager.
   */
	val filterForm = Form(
	    mapping(
	      "orderBy" -> text,
	      "item" -> longNumber
	      )(FilterForm.apply)(FilterForm.unapply))
  /**
  * Form object to set the status of an order.
  */
	val setStatusForm = Form(
	    mapping(
	      "id" -> longNumber,
	      "status" -> text
	      )(StatusForm.apply)(StatusForm.unapply))

  /**
   * Set the status of an order.
   */
  def setStatus = Action { implicit request =>
    setStatusForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	Redirect(routes.Application.error).withSession("user" -> user)
	    }.getOrElse{
	       Redirect(routes.Application.error)
	    }
      },
      orderData => {
        services.OrderService.setStatus(orderData.id, orderData.status)
        Redirect(routes.Application.showOrder(orderData.id)).
          flashing("success" -> "Category deleted!")
      })
  } 
 
   /**
   * Adds a new order to the system.
   */
  def newOrder = Action { implicit request =>
    orderForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.order(formWithErrors, services.ProductService.allProductsOrderByCategory, services.UserService.findUser(user), services.AdditionalsService.allAdditionalsOrderByCategory)).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.order(formWithErrors, services.ProductService.allProductsOrderByCategory, services.UserService.getDummy, services.AdditionalsService.allAdditionalsOrderByCategory))
        }
      },
      orderData => {
        var newOrder = services.OrderService.newOrder(orderData.user_id) 
        for(orderContent <- orderData.orderContents) {
          val additionalsList = scala.collection.mutable.MutableList[Additional]()
          for (additional <- orderContent.additionals){
        	additionalsList += services.AdditionalsService.getAdditional(additional.id)
          }
          newOrder = services.OrderService.createPositionForOrder(newOrder, orderContent.position, services.ProductService.getProduct(orderContent.id), orderContent.unit, additionalsList.toList)
        }
        
        services.OrderService.setTotalPrice(newOrder);
        Redirect(routes.Application.showOrder(newOrder.id)).
          flashing("success" -> "Order saved!")
      })
  }
}