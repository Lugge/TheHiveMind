package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import models._
import services.ProductService
import forms.CreateProductForm
import forms.DeleteProductForm

/**
 * Controller for product specific operations.
 * 
 * @author lk, js
 */
object ProductController extends Controller {

  /**
   * Form object for Product data.
   */
  val productForm = Form(
    mapping(
      "name" -> text,
      "price" -> of[Double],
      "category" -> longNumber(min = 1),
      "unit" -> text,
      "isAvailable" -> boolean,
      "isDeactivated" -> boolean
      )(CreateProductForm.apply)(CreateProductForm.unapply))
      
   /**
   * Form object to delete a product.
   */
  val productDeleteForm = Form(
    mapping(
      "id" -> longNumber)(DeleteProductForm.apply)(DeleteProductForm.unapply))
 
  /**
   * Form object to edit a product.
   */
  val editProductForm = Form(
	  tuple(
	  "id" -> longNumber,
      "name" -> text,
      "price" -> of[Double],
      "category" -> longNumber(min = 1),
      "unit" -> text,
      "isAvailable" -> boolean,
      "isDeactivated" -> boolean
	  )
   ) 
  /**
   * Adds a new product with the given data to the system.
   */
  def addProduct = Action { implicit request =>
    productForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.productManager(formWithErrors, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.productManager(formWithErrors, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.getDummy))
        }  
      },
      productData => {
        val newProduct = services.ProductService.addProduct(productData.name, productData.price, productData.category, productData.unit, productData.isAvailable, productData.isDeactivated)
        Redirect(routes.Application.productManager()).
          flashing("success" -> "Product saved!")
      })
  }
  
  /**
   * Edits an existing user.
   */
  def editProduct = Action { implicit request =>
    editProductForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.getDummy))
        }
      },
      productData => {         
        val newProduct = services.ProductService.editProduct(productData._1, productData._2, productData._3, productData._4, productData._5, productData._6)
        Redirect(routes.Application.productManager)
      }
    )
}


  /**
   * Delete a product from the system.
   */
  def deleteProduct(id: Long) = Action { implicit request =>
    productDeleteForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.getDummy))
        }  
      },
      productData => {
        services.ProductService.deleteProduct(id)
        Redirect(routes.Application.productManager()).
          flashing("success" -> "Product deleted!")
      })
  }
}