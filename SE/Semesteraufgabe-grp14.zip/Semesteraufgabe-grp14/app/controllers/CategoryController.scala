package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import models._
import services.CategoryService
import forms.CreateCategoryForm
import forms.DeleteCategoryForm

/**
 * Controller for category specific operations.
 * 
 * @author lk, js
 */
object CategoryController extends Controller {

  /**
   * Form object for Category data.
   */
  val categoryForm = Form(
    mapping(
      "name" -> text
      )(CreateCategoryForm.apply)(CreateCategoryForm.unapply))

   /**
   * Form object to delete a category.
   */
  val categoryDeleteForm = Form(
    mapping(
      "id" -> longNumber)(DeleteCategoryForm.apply)(DeleteCategoryForm.unapply))

  /**
   * Adds a new category with the given data to the system.
   */
  def addCategory = Action { implicit request =>
    categoryForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.categoryManager(formWithErrors, services.CategoryService.allCategorys, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.categoryManager(formWithErrors, services.CategoryService.allCategorys, services.UserService.getDummy))
        }
      },
      categoryData => {
        val newCategory = services.CategoryService.addCategory(categoryData.name)
        Redirect(routes.Application.categoryManager()).
          flashing("success" -> "Product saved!")
      })
  }
  
  /**
   * Delete a Category from the system.
   */
  def deleteCategory(id: Long) = Action { implicit request =>
    categoryDeleteForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.categoryManager(controllers.CategoryController.categoryForm, services.CategoryService.allCategorys, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.categoryManager(controllers.CategoryController.categoryForm, services.CategoryService.allCategorys, services.UserService.getDummy))
        }
      },
      categoryData => {
        services.CategoryService.deleteCategory(id)
        Redirect(routes.Application.categoryManager()).
          flashing("success" -> "Category deleted!")
      })
  }
}