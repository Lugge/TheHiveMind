package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import models._
import services.UserService
import forms.CreateUserForm
import forms.LoginUserForm

/**
 * Controller for user specific operations.
 * 
 * @author ob, scs, lk, js
 */
object UserController extends Controller {

  var lastDistance = 0; 
  /**
   * Form object for login.
   */
    val loginForm = Form(
    tuple(
      "name" -> text,
      "password" -> text
    ) verifying ("Ungueltiger Name oder Passwort.", result => result match {
      case (name, password) => services.UserService.login(name, password)
    })
  )
    
    
  /**
   * Form object for user data.
   */
  val userForm = Form(
    tuple(
      "name" -> nonEmptyText,
      "password" ->nonEmptyText(8),
      "postalCode" -> number ).verifying ("Der name existiert bereits.", result => services.UserService.checkUser(result._1) == true
      ).verifying ("Wir beliefern nur  im Umkreis von 20 Km.", result => services.UserService.checkDistance(result._3) == true
     )
     )
     
   /**
   * Form object for admins create an user. User can be created as Admins
   */
   val adminForm = Form(
    tuple(
      "name" -> nonEmptyText,
      "password" ->nonEmptyText(8),
      "postalCode" -> number,
      "isAdmin" -> boolean 
      ).verifying ("Name already exists", result => services.UserService.checkUser(result._1) == true
      )
     )
     
     /**
	   * Form object to edit an user.
	   */
     val editUserForm = Form(
      tuple(
      "id" -> longNumber,
      "name" -> nonEmptyText,
      "password" ->text,
      "postalCode" -> number,
      "isAdmin" -> boolean
      )
     ) 

  /**
   * Adds a new user with the given data to the system.
   */
  def addUser = Action { implicit request =>
    userForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.registration(formWithErrors, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.registration(formWithErrors, services.UserService.getDummy))
        }        
        },
      userData => {         
        var distance = UserService.getDistance(userData._3)
        distance = lastDistance
        val newUser = services.UserService.addUser(userData._1, userData._2, userData._3, false, distance)
        Redirect(routes.UserController.welcomeUser(newUser.name)).
          withSession("user" -> newUser.name)        
      })
  }
    
   /**
   * Adds a new user to the system. The user can be declared as admin.
   */
  def addAdmin = Action { implicit request =>
    adminForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.users(services.UserService.registeredUsers, formWithErrors, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.users(services.UserService.registeredUsers, formWithErrors, services.UserService.getDummy))
        }           
        },
      userData => {
        var distance = UserService.getDistance(userData._3)
        distance = lastDistance
        val newUser = services.UserService.addUser(userData._1, userData._2, userData._3, userData._4, distance)
        Redirect(routes.UserController.userManagement)
      })
  }
  
  /**
   * Edits an existing user.
   */
  def editUser = Action { implicit request =>
    editUserForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.users(services.UserService.registeredUsers, adminForm, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.users(services.UserService.registeredUsers, adminForm, services.UserService.getDummy))
        }
        },
      userData => {         
        val newUser = services.UserService.editUser(userData._1, userData._2, userData._3, userData._4, userData._5)
        Redirect(routes.UserController.userManagement)
      })
  }
  
  /**
   * Logs the given user on the system.
   */
  def login = Action { implicit request =>
    loginForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.login(formWithErrors, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.login(formWithErrors, services.UserService.getDummy))
        }
      },
      userData => {
        val user = services.UserService.findUser(userData._1)
        Redirect(routes.UserController.welcomeUser(user.name)).
          withSession("user" -> user.name)
      }		
    )
  }

  /**
   * Shows the welcome view for a newly registered user.
   */
  def welcomeUser(username: String) = Action {request =>
    request.session.get("user").map{ user =>
    	Ok(views.html.welcomeUser(username, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.welcomeUser(username, services.UserService.getDummy))
    }
  }

  /**
   * Shows the user management page.
   */
  def userManagement = Action {request =>
    request.session.get("user").map{ user =>
    	Ok(views.html.users(services.UserService.registeredUsers, adminForm, services.UserService.findUser(user))).withSession("user" -> user)
    }.getOrElse{
    	Ok(views.html.users(services.UserService.registeredUsers, adminForm, services.UserService.getDummy))
    }
    
  }

}