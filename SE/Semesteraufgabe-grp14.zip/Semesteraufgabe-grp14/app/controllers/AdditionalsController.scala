package controllers

import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import play.api.data.format.Formats._
import models._
import services.AdditionalsService
import forms.CreateAdditionalsForm
import forms.DeleteAdditionalsForm

/**
 * Controller for additionals specific operations.
 * 
 * @author lk, js
 */
object AdditionalsController extends Controller {

  /**
   * Form object for Additionals data.
   */
  val additionalsForm = Form(
    mapping(
      "name" -> text,
      "price" -> of[Double],
      "category_id" -> longNumber,
      "isAvailableAdd" -> boolean
      )(CreateAdditionalsForm.apply)(CreateAdditionalsForm.unapply))

  /**
   * Form object to delete an Additional.
   */
  val additionalsDeleteForm = Form(
    mapping(
      "id" -> longNumber)(DeleteAdditionalsForm.apply)(DeleteAdditionalsForm.unapply))

  /**
   * Adds a new Additional with the given data to the system.
   */
  def addAdditional = Action { implicit request =>
    additionalsForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, formWithErrors, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, formWithErrors, services.UserService.getDummy))
        }
   
      },
      additionalsData => {
        val newAdditional = services.AdditionalsService.addAdditional(additionalsData.name, additionalsData.price, additionalsData.category_id, additionalsData.isAvailableAdd)
        Redirect(routes.Application.productManager()).
          flashing("success" -> "Additional saved!")
      })
  }
  
  /**
   * Deletes an Additional from the system.
   * 
   * @param id Long: The id of the additional 
   */
  def deleteAdditional(id: Long) = Action { implicit request =>
    additionalsDeleteForm.bindFromRequest.fold(
      formWithErrors => {
        request.session.get("user").map{ user =>
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.findUser(user))).withSession("user" -> user)
        }.getOrElse{
        	BadRequest(views.html.productManager(controllers.ProductController.productForm, services.ProductService.allProductsOrderByCategory, services.CategoryService.allCategorys, services.AdditionalsService.allAdditionalsOrderByCategory, controllers.AdditionalsController.additionalsForm, services.UserService.getDummy))
        }        
      },
      productData => {
        services.AdditionalsService.deleteAdditional(id)
        Redirect(routes.Application.productManager()).
          flashing("success" -> "Additional deleted!")
      })
  }

}